﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace task3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(tbA.Text);
            double b = Convert.ToDouble(tbB.Text);
            double c = Convert.ToDouble(tbC.Text);
            double d = Convert.ToDouble(tbD.Text);
            double ee = Convert.ToDouble(tbE.Text);
            double f = Convert.ToDouble(tbF.Text);

            double small = a * c - b * b;
            double big = a * c * f + b * ee * d + d * b * ee - d * c * d - ee * ee * a - f * b * b;

            if (small > 0 && big != 0)
            {
                label.Content = "Результат: гипербола";
            } else if (small < 0 && big != 0)
            {
                label.Content = "Результат: эллипс";
            } else if(small == 0 && big != 0)
            {
                label.Content = "Результат: парабола";
            } else if(small > 0 && big == 0)
            {
                label.Content = "Результат: две мнимые прямые";
            }
            else if (small < 0 && big == 0)
            {
                label.Content = "Результат: две пересекающиеся прямые";
            }
            else if (small == 0 && big == 0)
            {
                label.Content = "Результат: две параллельные прямые";
            }

            //label.Content += " " + small + " " + big;

        }

        private void tbA_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbA.Text.IndexOf(',') != -1) || (tbA.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbA.Text.IndexOf('-') != -1) || (tbA.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }

        private void tbB_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbB.Text.IndexOf(',') != -1) || (tbB.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbB.Text.IndexOf('-') != -1) || (tbB.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }

        private void tbD_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbD.Text.IndexOf(',') != -1) || (tbD.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbD.Text.IndexOf('-') != -1) || (tbD.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }

        private void tbE_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbE.Text.IndexOf(',') != -1) || (tbE.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbE.Text.IndexOf('-') != -1) || (tbE.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }

        private void tbF_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbF.Text.IndexOf(',') != -1) || (tbF.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbF.Text.IndexOf('-') != -1) || (tbF.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }
    }
}
