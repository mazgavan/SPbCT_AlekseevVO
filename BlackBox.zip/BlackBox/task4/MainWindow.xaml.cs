﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace task4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(tbA.Text);
            double b = Convert.ToDouble(tbB.Text);
            double c = Convert.ToDouble(tbC.Text);

            if (a==b && b==c)
            {
                label.Content = "Результат: треугольник равносторонний";
            } else if((a==b)||(b==c)||(a==c))
            {
                label.Content = "Результат: треугольник равнобедренный";
            } else
            {
                label.Content = "Результат: треугольник разносторонний";
            }
            if (a*a+b*b==c*c || a*a+c*c==b*b || a*a==b*b+c*c)
            {
                label.Content += " и прямоугольный";
            }
        }

        private void tbA_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbA.Text.IndexOf(',') != -1) || (tbA.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            
            e.Handled = true;
        }

        private void tbB_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbB.Text.IndexOf(',') != -1) || (tbB.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            
            e.Handled = true;
        }
    }
}
