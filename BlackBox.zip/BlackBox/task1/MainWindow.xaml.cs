﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace task1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(tbA.Text);
            double b = Convert.ToDouble(tbB.Text);
            double c = Convert.ToDouble(tbC.Text);
            double desc = b * b - 4 * a * c;
            if (desc>0)
            {
                label.Content = "Результат: x1 = " + Math.Round(((-1) * b - Math.Sqrt(desc)) / (2 * a), 3, MidpointRounding.AwayFromZero) + "; x2 = " + Math.Round(((-1) * b + Math.Sqrt(desc)) / (2 * a), 3, MidpointRounding.AwayFromZero);
            } else if (desc == 0)
            {
                label.Content = "Результат: x1,2 = " + Math.Round(((-1) * b) / (2 * a), 3, MidpointRounding.AwayFromZero);
            } else
            {
                label.Content = "Результат: корней нет";
            }
        }

        

        private void tbA_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbA.Text.IndexOf(',') != -1) || (tbA.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbA.Text.IndexOf('-') != -1) || (tbA.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }

        private void tbB_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (char.IsControl(e.Text, 0)) return;
            if ((e.Text[0] >= '0') && (e.Text[0] <= '9')) return;
            if (e.Text[0] == ',')
            {
                if ((tbB.Text.IndexOf(',') != -1) || (tbB.Text.Length == 0))
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.Text[0] == '-')
            {
                if ((tbB.Text.IndexOf('-') != -1) || (tbB.Text.Length != 0))
                {
                    e.Handled = true;
                }
                return;
            }
            e.Handled = true;
        }
    }
}
